<?php
/**
 * Plugin Name: Auto Resave Content
 * Plugin URI: https://example.com/auto-resave-content
 * Description: Automatically re-saves all posts and pages to refresh permalinks, update caches, and trigger save hooks.
 * Version: 1.0.0
 * Author: Your Name
 * License: GPL v2 or later
 * License URI: https://www.gnu.org/licenses/gpl-2.0.html
 */

if (!defined('ABSPATH')) {
    exit;
}

class Auto_Resave_Content {

    private $batch_size = 50;

    public function __construct() {
        add_action('admin_menu', [$this, 'add_admin_menu']);
        add_action('admin_enqueue_scripts', [$this, 'enqueue_scripts']);
        add_action('wp_ajax_arc_resave_batch', [$this, 'ajax_resave_batch']);
        add_action('wp_ajax_arc_get_content_count', [$this, 'ajax_get_content_count']);
    }

    public function add_admin_menu() {
        add_management_page(
            'Auto Resave Content',
            'Auto Resave Content',
            'manage_options',
            'auto-resave-content',
            [$this, 'render_admin_page']
        );
    }

    public function enqueue_scripts($hook) {
        if ($hook !== 'tools_page_auto-resave-content') {
            return;
        }

        wp_enqueue_style(
            'arc-admin-style',
            plugin_dir_url(__FILE__) . 'admin-style.css',
            [],
            '1.0.0'
        );

        wp_enqueue_script(
            'arc-admin-script',
            plugin_dir_url(__FILE__) . 'admin-script.js',
            ['jquery'],
            '1.0.0',
            true
        );

        wp_localize_script('arc-admin-script', 'arcData', [
            'ajaxUrl' => admin_url('admin-ajax.php'),
            'nonce' => wp_create_nonce('arc_resave_nonce'),
            'batchSize' => $this->batch_size,
        ]);
    }

    public function render_admin_page() {
        if (!current_user_can('manage_options')) {
            wp_die(__('You do not have sufficient permissions to access this page.'));
        }
        ?>
        <div class="wrap arc-wrap">
            <h1>Auto Resave Content</h1>
            <p>This tool will re-save all your posts and pages. This is useful for:</p>
            <ul>
                <li>Refreshing permalinks after changing permalink structure</li>
                <li>Triggering post save hooks for plugins that need to rebuild data</li>
                <li>Updating cached content</li>
                <li>Regenerating metadata</li>
            </ul>

            <div class="arc-options">
                <h2>Options</h2>
                <label>
                    <input type="checkbox" id="arc-include-posts" checked>
                    Include Posts
                </label>
                <br>
                <label>
                    <input type="checkbox" id="arc-include-pages" checked>
                    Include Pages
                </label>
                <br>
                <label>
                    <input type="checkbox" id="arc-include-custom" checked>
                    Include Custom Post Types
                </label>
                <br><br>
                <label>
                    Post Status:
                    <select id="arc-post-status">
                        <option value="any">Any</option>
                        <option value="publish" selected>Published Only</option>
                        <option value="draft">Drafts Only</option>
                        <option value="private">Private Only</option>
                    </select>
                </label>
            </div>

            <div class="arc-controls">
                <button id="arc-start-btn" class="button button-primary">Start Resaving</button>
                <button id="arc-stop-btn" class="button" disabled>Stop</button>
            </div>

            <div class="arc-progress-container" style="display: none;">
                <h2>Progress</h2>
                <div class="arc-progress-bar-wrapper">
                    <div class="arc-progress-bar"></div>
                </div>
                <p class="arc-progress-text">
                    <span id="arc-processed">0</span> / <span id="arc-total">0</span> items processed
                </p>
                <p class="arc-status"></p>
            </div>

            <div class="arc-log-container" style="display: none;">
                <h2>Log</h2>
                <div class="arc-log"></div>
            </div>

            <div class="arc-complete-message" style="display: none;">
                <h2>Complete!</h2>
                <p>All content has been re-saved successfully.</p>
            </div>
        </div>
        <?php
    }

    public function ajax_get_content_count() {
        check_ajax_referer('arc_resave_nonce', 'nonce');

        if (!current_user_can('manage_options')) {
            wp_send_json_error('Unauthorized');
        }

        $post_types = $this->get_selected_post_types();
        $post_status = sanitize_text_field($_POST['post_status'] ?? 'publish');

        $args = [
            'post_type' => $post_types,
            'post_status' => $post_status === 'any' ? ['publish', 'draft', 'private', 'pending', 'future'] : $post_status,
            'posts_per_page' => -1,
            'fields' => 'ids',
            'no_found_rows' => true,
            'update_post_meta_cache' => false,
            'update_post_term_cache' => false,
        ];

        $posts = get_posts($args);

        wp_send_json_success([
            'count' => count($posts),
            'ids' => $posts,
        ]);
    }

    public function ajax_resave_batch() {
        check_ajax_referer('arc_resave_nonce', 'nonce');

        if (!current_user_can('manage_options')) {
            wp_send_json_error('Unauthorized');
        }

        $ids = isset($_POST['ids']) ? array_map('intval', $_POST['ids']) : [];

        if (empty($ids)) {
            wp_send_json_error('No IDs provided');
        }

        $results = [];

        foreach ($ids as $post_id) {
            $post = get_post($post_id);

            if (!$post) {
                $results[] = [
                    'id' => $post_id,
                    'success' => false,
                    'message' => 'Post not found',
                ];
                continue;
            }

            // Remove kses filters to preserve content exactly
            kses_remove_filters();

            // Update the post (this triggers all save hooks)
            $result = wp_update_post([
                'ID' => $post_id,
                'post_modified' => current_time('mysql'),
                'post_modified_gmt' => current_time('mysql', 1),
            ], true);

            // Restore kses filters
            kses_init_filters();

            if (is_wp_error($result)) {
                $results[] = [
                    'id' => $post_id,
                    'success' => false,
                    'title' => $post->post_title,
                    'type' => $post->post_type,
                    'message' => $result->get_error_message(),
                ];
            } else {
                // Clear post cache
                clean_post_cache($post_id);

                $results[] = [
                    'id' => $post_id,
                    'success' => true,
                    'title' => $post->post_title,
                    'type' => $post->post_type,
                    'message' => 'Resaved successfully',
                ];
            }
        }

        wp_send_json_success($results);
    }

    private function get_selected_post_types() {
        $types = [];

        $include_posts = isset($_POST['include_posts']) && $_POST['include_posts'] === 'true';
        $include_pages = isset($_POST['include_pages']) && $_POST['include_pages'] === 'true';
        $include_custom = isset($_POST['include_custom']) && $_POST['include_custom'] === 'true';

        if ($include_posts) {
            $types[] = 'post';
        }

        if ($include_pages) {
            $types[] = 'page';
        }

        if ($include_custom) {
            $custom_types = get_post_types([
                'public' => true,
                '_builtin' => false,
            ], 'names');

            $types = array_merge($types, array_values($custom_types));
        }

        return !empty($types) ? $types : ['post', 'page'];
    }
}

new Auto_Resave_Content();
