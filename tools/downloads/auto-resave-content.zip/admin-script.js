(function($) {
    'use strict';

    let isRunning = false;
    let shouldStop = false;
    let allIds = [];
    let processedCount = 0;
    let totalCount = 0;

    const elements = {
        startBtn: null,
        stopBtn: null,
        progressContainer: null,
        progressBar: null,
        processedSpan: null,
        totalSpan: null,
        statusText: null,
        logContainer: null,
        log: null,
        completeMessage: null,
        includePosts: null,
        includePages: null,
        includeCustom: null,
        postStatus: null
    };

    function init() {
        elements.startBtn = $('#arc-start-btn');
        elements.stopBtn = $('#arc-stop-btn');
        elements.progressContainer = $('.arc-progress-container');
        elements.progressBar = $('.arc-progress-bar');
        elements.processedSpan = $('#arc-processed');
        elements.totalSpan = $('#arc-total');
        elements.statusText = $('.arc-status');
        elements.logContainer = $('.arc-log-container');
        elements.log = $('.arc-log');
        elements.completeMessage = $('.arc-complete-message');
        elements.includePosts = $('#arc-include-posts');
        elements.includePages = $('#arc-include-pages');
        elements.includeCustom = $('#arc-include-custom');
        elements.postStatus = $('#arc-post-status');

        elements.startBtn.on('click', startResave);
        elements.stopBtn.on('click', stopResave);
    }

    function startResave() {
        if (isRunning) return;

        isRunning = true;
        shouldStop = false;
        processedCount = 0;
        allIds = [];

        elements.startBtn.prop('disabled', true);
        elements.stopBtn.prop('disabled', false);
        elements.progressContainer.show();
        elements.logContainer.show();
        elements.completeMessage.hide();
        elements.log.empty();
        elements.progressBar.css('width', '0%');

        updateStatus('Fetching content list...');

        $.ajax({
            url: arcData.ajaxUrl,
            type: 'POST',
            data: {
                action: 'arc_get_content_count',
                nonce: arcData.nonce,
                include_posts: elements.includePosts.is(':checked'),
                include_pages: elements.includePages.is(':checked'),
                include_custom: elements.includeCustom.is(':checked'),
                post_status: elements.postStatus.val()
            },
            success: function(response) {
                if (response.success) {
                    allIds = response.data.ids;
                    totalCount = response.data.count;
                    elements.totalSpan.text(totalCount);
                    elements.processedSpan.text('0');

                    if (totalCount === 0) {
                        updateStatus('No content found matching your criteria.');
                        finishResave();
                        return;
                    }

                    updateStatus('Starting resave process...');
                    processBatch();
                } else {
                    updateStatus('Error: ' + response.data);
                    finishResave();
                }
            },
            error: function() {
                updateStatus('Error fetching content list.');
                finishResave();
            }
        });
    }

    function processBatch() {
        if (shouldStop || allIds.length === 0) {
            finishResave();
            return;
        }

        const batchIds = allIds.splice(0, arcData.batchSize);

        updateStatus('Processing batch of ' + batchIds.length + ' items...');

        $.ajax({
            url: arcData.ajaxUrl,
            type: 'POST',
            data: {
                action: 'arc_resave_batch',
                nonce: arcData.nonce,
                ids: batchIds
            },
            success: function(response) {
                if (response.success) {
                    response.data.forEach(function(item) {
                        processedCount++;
                        addLogEntry(item);
                    });

                    updateProgress();

                    if (allIds.length > 0 && !shouldStop) {
                        setTimeout(processBatch, 100);
                    } else {
                        finishResave();
                    }
                } else {
                    updateStatus('Error: ' + response.data);
                    finishResave();
                }
            },
            error: function() {
                updateStatus('Error processing batch. Retrying...');
                allIds = batchIds.concat(allIds);
                setTimeout(processBatch, 1000);
            }
        });
    }

    function stopResave() {
        shouldStop = true;
        updateStatus('Stopping after current batch...');
    }

    function finishResave() {
        isRunning = false;
        elements.startBtn.prop('disabled', false);
        elements.stopBtn.prop('disabled', true);

        if (shouldStop) {
            updateStatus('Stopped by user. ' + processedCount + ' items were processed.');
        } else if (processedCount === totalCount && totalCount > 0) {
            elements.completeMessage.show();
            updateStatus('All done!');
        }
    }

    function updateProgress() {
        const percentage = totalCount > 0 ? (processedCount / totalCount) * 100 : 0;
        elements.progressBar.css('width', percentage + '%');
        elements.processedSpan.text(processedCount);
    }

    function updateStatus(message) {
        elements.statusText.text(message);
    }

    function addLogEntry(item) {
        const statusClass = item.success ? 'success' : 'error';
        const entry = $('<div>')
            .addClass('arc-log-entry')
            .addClass(statusClass)
            .text('[' + item.type + '] ' + item.title + ' (ID: ' + item.id + ') - ' + item.message);

        elements.log.append(entry);
        elements.log.scrollTop(elements.log[0].scrollHeight);
    }

    $(document).ready(init);

})(jQuery);
