document.addEventListener('DOMContentLoaded', function() {
    const slides = document.querySelectorAll('.slide');
    const dots = document.querySelectorAll('.slider-dot');
    const prevBtn = document.querySelector('.slider-prev');
    const nextBtn = document.querySelector('.slider-next');
    let currentSlide = 1;
    let autoPlayInterval;
    const autoPlayDelay = 5000;

    function goToSlide(slideNum) {
        // Remove active class from all slides and dots
        slides.forEach(slide => slide.classList.remove('active'));
        dots.forEach(dot => dot.classList.remove('active'));

        // Add active class to current slide and dot
        document.querySelector('.slide[data-slide="' + slideNum + '"]').classList.add('active');
        document.querySelector('.slider-dot[data-slide="' + slideNum + '"]').classList.add('active');

        currentSlide = slideNum;
    }

    function nextSlide() {
        let next = currentSlide + 1;
        if (next > slides.length) next = 1;
        goToSlide(next);
    }

    function prevSlide() {
        let prev = currentSlide - 1;
        if (prev < 1) prev = slides.length;
        goToSlide(prev);
    }

    function startAutoPlay() {
        autoPlayInterval = setInterval(nextSlide, autoPlayDelay);
    }

    function stopAutoPlay() {
        clearInterval(autoPlayInterval);
    }

    // Event listeners
    if (nextBtn) {
        nextBtn.addEventListener('click', function() {
            stopAutoPlay();
            nextSlide();
            startAutoPlay();
        });
    }

    if (prevBtn) {
        prevBtn.addEventListener('click', function() {
            stopAutoPlay();
            prevSlide();
            startAutoPlay();
        });
    }

    dots.forEach(function(dot) {
        dot.addEventListener('click', function() {
            stopAutoPlay();
            goToSlide(parseInt(dot.dataset.slide));
            startAutoPlay();
        });
    });

    // Pause on hover
    var sliderContainer = document.querySelector('.hero-slider');
    if (sliderContainer) {
        sliderContainer.addEventListener('mouseenter', stopAutoPlay);
        sliderContainer.addEventListener('mouseleave', startAutoPlay);
    }

    // Start autoplay
    if (slides.length > 0) {
        startAutoPlay();
    }
});
