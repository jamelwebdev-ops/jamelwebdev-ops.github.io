<?php
if (!defined('ABSPATH')) exit;

function wdm_setup() {
    add_theme_support('title-tag');
    add_theme_support('post-thumbnails');
    add_theme_support('html5', ['search-form', 'comment-form', 'comment-list', 'gallery', 'caption']);
    register_nav_menus(['primary' => __('Primary Menu', 'windows-doors-modern')]);
}
add_action('after_setup_theme', 'wdm_setup');

function wdm_scripts() {
    wp_enqueue_style('google-fonts', 'https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&family=Playfair+Display:wght@600;700&display=swap', [], null);
    wp_enqueue_style('wdm-style', get_stylesheet_uri(), ['google-fonts'], '1.0.0');
    wp_enqueue_script('wdm-slider', get_template_directory_uri() . '/js/slider.js', [], '1.0.0', true);
}
add_action('wp_enqueue_scripts', 'wdm_scripts');
