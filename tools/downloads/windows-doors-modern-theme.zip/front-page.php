<?php get_header(); ?>

    <!-- Hero Slider Section -->
    <section class="hero-slider">
        <!-- Slides Container -->
        <div class="slider-container">
            <!-- Slide 1 - Windows -->
            <div class="slide active" data-slide="1">
                <div class="slide-bg slide-bg-1"></div>
                <div class="slide-overlay"></div>
                <div class="container slide-inner">
                    <div class="slide-content">
                        <span class="hero-badge"><?php echo esc_html__('Trusted by 10,000+ Homeowners', 'windows-doors-modern'); ?></span>
                        <h1 class="hero-title"><?php echo esc_html__('Transform Your Home with Premium Windows', 'windows-doors-modern'); ?></h1>
                        <p class="hero-subtitle"><?php echo esc_html__('Energy-efficient windows that reduce costs and enhance comfort. Expert installation with lifetime warranty.', 'windows-doors-modern'); ?></p>
                        <div class="hero-cta">
                            <a href="#quote" class="btn btn-primary btn-lg">
                                <?php echo esc_html__('Get Free Estimate', 'windows-doors-modern'); ?>
                                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                    <line x1="5" y1="12" x2="19" y2="12"></line>
                                    <polyline points="12 5 19 12 12 19"></polyline>
                                </svg>
                            </a>
                            <a href="tel:8883832848" class="btn btn-outline-white btn-lg">
                                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                    <path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72 12.84 12.84 0 0 0 .7 2.81 2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45 12.84 12.84 0 0 0 2.81.7A2 2 0 0 1 22 16.92z"/>
                                </svg>
                                <?php echo esc_html__('Call Now', 'windows-doors-modern'); ?>
                            </a>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Slide 2 - Doors -->
            <div class="slide" data-slide="2">
                <div class="slide-bg slide-bg-2"></div>
                <div class="slide-overlay"></div>
                <div class="container slide-inner">
                    <div class="slide-content">
                        <span class="hero-badge"><?php echo esc_html__('Expert Installation Services', 'windows-doors-modern'); ?></span>
                        <h1 class="hero-title"><?php echo esc_html__('Beautiful Doors That Make a Statement', 'windows-doors-modern'); ?></h1>
                        <p class="hero-subtitle"><?php echo esc_html__('Entry doors, French doors, and sliding glass doors that enhance curb appeal and security.', 'windows-doors-modern'); ?></p>
                        <div class="hero-cta">
                            <a href="#quote" class="btn btn-primary btn-lg">
                                <?php echo esc_html__('Get Free Estimate', 'windows-doors-modern'); ?>
                                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                    <line x1="5" y1="12" x2="19" y2="12"></line>
                                    <polyline points="12 5 19 12 12 19"></polyline>
                                </svg>
                            </a>
                            <a href="tel:8883832848" class="btn btn-outline-white btn-lg">
                                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                    <path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72 12.84 12.84 0 0 0 .7 2.81 2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45 12.84 12.84 0 0 0 2.81.7A2 2 0 0 1 22 16.92z"/>
                                </svg>
                                <?php echo esc_html__('Call Now', 'windows-doors-modern'); ?>
                            </a>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Slide 3 - Siding -->
            <div class="slide" data-slide="3">
                <div class="slide-bg slide-bg-3"></div>
                <div class="slide-overlay"></div>
                <div class="container slide-inner">
                    <div class="slide-content">
                        <span class="hero-badge"><?php echo esc_html__('Protect Your Investment', 'windows-doors-modern'); ?></span>
                        <h1 class="hero-title"><?php echo esc_html__('Premium Siding for Lasting Protection', 'windows-doors-modern'); ?></h1>
                        <p class="hero-subtitle"><?php echo esc_html__('Durable vinyl and fiber cement siding that protects from the elements and adds lasting value.', 'windows-doors-modern'); ?></p>
                        <div class="hero-cta">
                            <a href="#quote" class="btn btn-primary btn-lg">
                                <?php echo esc_html__('Get Free Estimate', 'windows-doors-modern'); ?>
                                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                    <line x1="5" y1="12" x2="19" y2="12"></line>
                                    <polyline points="12 5 19 12 12 19"></polyline>
                                </svg>
                            </a>
                            <a href="tel:8883832848" class="btn btn-outline-white btn-lg">
                                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                    <path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72 12.84 12.84 0 0 0 .7 2.81 2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45 12.84 12.84 0 0 0 2.81.7A2 2 0 0 1 22 16.92z"/>
                                </svg>
                                <?php echo esc_html__('Call Now', 'windows-doors-modern'); ?>
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Slider Navigation Arrows -->
        <button class="slider-arrow slider-prev" aria-label="<?php echo esc_attr__('Previous slide', 'windows-doors-modern'); ?>">
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                <polyline points="15 18 9 12 15 6"></polyline>
            </svg>
        </button>
        <button class="slider-arrow slider-next" aria-label="<?php echo esc_attr__('Next slide', 'windows-doors-modern'); ?>">
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                <polyline points="9 18 15 12 9 6"></polyline>
            </svg>
        </button>

        <!-- Slider Dots -->
        <div class="slider-dots">
            <button class="slider-dot active" data-slide="1" aria-label="<?php echo esc_attr__('Go to slide 1', 'windows-doors-modern'); ?>"></button>
            <button class="slider-dot" data-slide="2" aria-label="<?php echo esc_attr__('Go to slide 2', 'windows-doors-modern'); ?>"></button>
            <button class="slider-dot" data-slide="3" aria-label="<?php echo esc_attr__('Go to slide 3', 'windows-doors-modern'); ?>"></button>
        </div>

        <!-- Stats Bar -->
        <div class="slider-stats">
            <div class="container">
                <div class="hero-stats">
                    <div class="stat">
                        <span class="stat-number">25+</span>
                        <span class="stat-label"><?php echo esc_html__('Years Experience', 'windows-doors-modern'); ?></span>
                    </div>
                    <div class="stat">
                        <span class="stat-number">10K+</span>
                        <span class="stat-label"><?php echo esc_html__('Happy Customers', 'windows-doors-modern'); ?></span>
                    </div>
                    <div class="stat">
                        <span class="stat-number">100%</span>
                        <span class="stat-label"><?php echo esc_html__('Satisfaction', 'windows-doors-modern'); ?></span>
                    </div>
                    <div class="stat">
                        <span class="stat-number"><?php echo esc_html__('Lifetime', 'windows-doors-modern'); ?></span>
                        <span class="stat-label"><?php echo esc_html__('Warranty', 'windows-doors-modern'); ?></span>
                    </div>
                </div>
            </div>
        </div>

        <!-- Floating Quote Form -->
        <div class="slider-form" id="quote">
            <div class="form-card">
                <div class="form-header">
                    <h2><?php echo esc_html__('Get Your Free Quote', 'windows-doors-modern'); ?></h2>
                    <p><?php echo esc_html__('No obligation, no pressure', 'windows-doors-modern'); ?></p>
                </div>
                <form class="quote-form" action="#" method="post">
                    <div class="form-group">
                        <label for="name"><?php echo esc_html__('Full Name', 'windows-doors-modern'); ?></label>
                        <input type="text" id="name" name="name" placeholder="<?php echo esc_attr__('John Smith', 'windows-doors-modern'); ?>" required>
                    </div>
                    <div class="form-group">
                        <label for="email"><?php echo esc_html__('Email', 'windows-doors-modern'); ?></label>
                        <input type="email" id="email" name="email" placeholder="<?php echo esc_attr__('john@email.com', 'windows-doors-modern'); ?>" required>
                    </div>
                    <div class="form-group">
                        <label for="phone"><?php echo esc_html__('Phone', 'windows-doors-modern'); ?></label>
                        <input type="tel" id="phone" name="phone" placeholder="<?php echo esc_attr__('(555) 123-4567', 'windows-doors-modern'); ?>" required>
                    </div>
                    <div class="form-group">
                        <label for="service"><?php echo esc_html__('Service Needed', 'windows-doors-modern'); ?></label>
                        <select id="service" name="service" required>
                            <option value=""><?php echo esc_html__('Select service...', 'windows-doors-modern'); ?></option>
                            <option value="windows"><?php echo esc_html__('Windows', 'windows-doors-modern'); ?></option>
                            <option value="doors"><?php echo esc_html__('Doors', 'windows-doors-modern'); ?></option>
                            <option value="siding"><?php echo esc_html__('Siding', 'windows-doors-modern'); ?></option>
                            <option value="multiple"><?php echo esc_html__('Multiple Services', 'windows-doors-modern'); ?></option>
                        </select>
                    </div>
                    <button type="submit" class="btn btn-primary btn-block">
                        <?php echo esc_html__('Request Free Quote', 'windows-doors-modern'); ?>
                        <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                            <line x1="5" y1="12" x2="19" y2="12"></line>
                            <polyline points="12 5 19 12 12 19"></polyline>
                        </svg>
                    </button>
                </form>
                <p class="form-disclaimer"><?php echo esc_html__('By submitting, you agree to receive communications from us.', 'windows-doors-modern'); ?></p>
            </div>
        </div>
    </section>

    <!-- Trust Badges -->
    <section class="trust-section">
        <div class="container">
            <div class="trust-badges">
                <div class="trust-badge">
                    <svg width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                        <path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/>
                        <polyline points="9 12 11 14 15 10"/>
                    </svg>
                    <span><?php echo esc_html__('Licensed & Insured', 'windows-doors-modern'); ?></span>
                </div>
                <div class="trust-badge">
                    <svg width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                        <circle cx="12" cy="8" r="7"/>
                        <polyline points="8.21 13.89 7 23 12 20 17 23 15.79 13.88"/>
                    </svg>
                    <span><?php echo esc_html__('Award Winning', 'windows-doors-modern'); ?></span>
                </div>
                <div class="trust-badge">
                    <svg width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                        <path d="M12 2L2 7l10 5 10-5-10-5zM2 17l10 5 10-5M2 12l10 5 10-5"/>
                    </svg>
                    <span><?php echo esc_html__('Lifetime Warranty', 'windows-doors-modern'); ?></span>
                </div>
                <div class="trust-badge">
                    <svg width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                        <rect x="1" y="4" width="22" height="16" rx="2" ry="2"/>
                        <line x1="1" y1="10" x2="23" y2="10"/>
                    </svg>
                    <span><?php echo esc_html__('Flexible Financing', 'windows-doors-modern'); ?></span>
                </div>
                <div class="trust-badge">
                    <svg width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                        <polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"/>
                    </svg>
                    <span><?php echo esc_html__('5-Star Rated', 'windows-doors-modern'); ?></span>
                </div>
            </div>
        </div>
    </section>

    <!-- Services Section -->
    <section class="services" id="services">
        <div class="container">
            <div class="section-header">
                <span class="section-badge"><?php echo esc_html__('Our Services', 'windows-doors-modern'); ?></span>
                <h2 class="section-title"><?php echo esc_html__('Premium Solutions for Your Home', 'windows-doors-modern'); ?></h2>
                <p class="section-subtitle"><?php echo esc_html__('We provide high-quality windows, doors, and siding installation with expert craftsmanship and attention to detail.', 'windows-doors-modern'); ?></p>
            </div>
            <div class="services-grid">
                <div class="service-card">
                    <div class="service-image">
                        <div class="service-image-placeholder">
                            <svg width="64" height="64" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5">
                                <rect x="3" y="3" width="18" height="18" rx="2"/>
                                <line x1="12" y1="3" x2="12" y2="21"/>
                                <line x1="3" y1="12" x2="21" y2="12"/>
                            </svg>
                        </div>
                    </div>
                    <div class="service-content">
                        <h3><?php echo esc_html__('Windows', 'windows-doors-modern'); ?></h3>
                        <p><?php echo esc_html__('Energy-efficient windows that reduce heating and cooling costs while enhancing your home\'s beauty and comfort.', 'windows-doors-modern'); ?></p>
                        <ul class="service-features">
                            <li><?php echo esc_html__('Double & Triple Pane Options', 'windows-doors-modern'); ?></li>
                            <li><?php echo esc_html__('UV Protection', 'windows-doors-modern'); ?></li>
                            <li><?php echo esc_html__('Noise Reduction', 'windows-doors-modern'); ?></li>
                        </ul>
                        <a href="#quote" class="btn btn-text">
                            <?php echo esc_html__('Learn More', 'windows-doors-modern'); ?>
                            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                <line x1="5" y1="12" x2="19" y2="12"></line>
                                <polyline points="12 5 19 12 12 19"></polyline>
                            </svg>
                        </a>
                    </div>
                </div>
                <div class="service-card">
                    <div class="service-image">
                        <div class="service-image-placeholder">
                            <svg width="64" height="64" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5">
                                <path d="M3 21h18"/>
                                <path d="M5 21V7l7-4 7 4v14"/>
                                <path d="M9 21v-6h6v6"/>
                                <path d="M10 9h4"/>
                            </svg>
                        </div>
                    </div>
                    <div class="service-content">
                        <h3><?php echo esc_html__('Doors', 'windows-doors-modern'); ?></h3>
                        <p><?php echo esc_html__('Beautiful entry doors, sliding glass doors, and French doors that enhance your home\'s curb appeal and security.', 'windows-doors-modern'); ?></p>
                        <ul class="service-features">
                            <li><?php echo esc_html__('Entry & Patio Doors', 'windows-doors-modern'); ?></li>
                            <li><?php echo esc_html__('High Security Locks', 'windows-doors-modern'); ?></li>
                            <li><?php echo esc_html__('Custom Designs', 'windows-doors-modern'); ?></li>
                        </ul>
                        <a href="#quote" class="btn btn-text">
                            <?php echo esc_html__('Learn More', 'windows-doors-modern'); ?>
                            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                <line x1="5" y1="12" x2="19" y2="12"></line>
                                <polyline points="12 5 19 12 12 19"></polyline>
                            </svg>
                        </a>
                    </div>
                </div>
                <div class="service-card">
                    <div class="service-image">
                        <div class="service-image-placeholder">
                            <svg width="64" height="64" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5">
                                <path d="M3 21h18"/>
                                <path d="M5 21V5a2 2 0 0 1 2-2h10a2 2 0 0 1 2 2v16"/>
                                <path d="M9 21v-4h6v4"/>
                                <line x1="3" y1="7" x2="5" y2="7"/>
                                <line x1="3" y1="11" x2="5" y2="11"/>
                                <line x1="3" y1="15" x2="5" y2="15"/>
                                <line x1="19" y1="7" x2="21" y2="7"/>
                                <line x1="19" y1="11" x2="21" y2="11"/>
                                <line x1="19" y1="15" x2="21" y2="15"/>
                            </svg>
                        </div>
                    </div>
                    <div class="service-content">
                        <h3><?php echo esc_html__('Siding', 'windows-doors-modern'); ?></h3>
                        <p><?php echo esc_html__('Durable siding solutions that protect your home from the elements while adding beauty and lasting value.', 'windows-doors-modern'); ?></p>
                        <ul class="service-features">
                            <li><?php echo esc_html__('Vinyl & Fiber Cement', 'windows-doors-modern'); ?></li>
                            <li><?php echo esc_html__('Weather Resistant', 'windows-doors-modern'); ?></li>
                            <li><?php echo esc_html__('Low Maintenance', 'windows-doors-modern'); ?></li>
                        </ul>
                        <a href="#quote" class="btn btn-text">
                            <?php echo esc_html__('Learn More', 'windows-doors-modern'); ?>
                            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                <line x1="5" y1="12" x2="19" y2="12"></line>
                                <polyline points="12 5 19 12 12 19"></polyline>
                            </svg>
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Special Offers -->
    <section class="offers">
        <div class="container">
            <div class="offers-grid">
                <div class="offer-card offer-primary">
                    <div class="offer-badge"><?php echo esc_html__('Limited Time', 'windows-doors-modern'); ?></div>
                    <div class="offer-content">
                        <span class="offer-value">$100</span>
                        <h3><?php echo esc_html__('Gift Card', 'windows-doors-modern'); ?></h3>
                        <p><?php echo esc_html__('Purchase over $2,000 worth of Milgard Windows and/or doors and receive a $100 Visa gift card!', 'windows-doors-modern'); ?></p>
                        <a href="#quote" class="btn btn-white"><?php echo esc_html__('Claim Offer', 'windows-doors-modern'); ?></a>
                    </div>
                </div>
                <div class="offer-card offer-dark">
                    <div class="offer-badge"><?php echo esc_html__('Special', 'windows-doors-modern'); ?></div>
                    <div class="offer-content">
                        <span class="offer-value"><?php echo esc_html__('FREE', 'windows-doors-modern'); ?></span>
                        <h3><?php echo esc_html__('Bonus Window', 'windows-doors-modern'); ?></h3>
                        <p><?php echo esc_html__('Get a free window with the purchase of vinyl or fiber cement siding, or get a free pet patio door!', 'windows-doors-modern'); ?></p>
                        <a href="#quote" class="btn btn-primary"><?php echo esc_html__('Claim Offer', 'windows-doors-modern'); ?></a>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- About Section -->
    <section class="about" id="about">
        <div class="container about-inner">
            <div class="about-images">
                <div class="about-image-grid">
                    <div class="about-img img-1"></div>
                    <div class="about-img img-2"></div>
                    <div class="about-img img-3"></div>
                </div>
                <div class="experience-badge">
                    <span class="exp-number">25+</span>
                    <span class="exp-text"><?php echo esc_html__('Years of Excellence', 'windows-doors-modern'); ?></span>
                </div>
            </div>
            <div class="about-content">
                <span class="section-badge"><?php echo esc_html__('About Us', 'windows-doors-modern'); ?></span>
                <h2 class="section-title"><?php echo esc_html__('Your Trusted Partner in Home Improvement', 'windows-doors-modern'); ?></h2>
                <p class="about-text"><?php echo esc_html__('Since 1995, Windows & Doors has been providing Las Vegas homeowners with premium quality windows, doors, and siding solutions. Our commitment to excellence and customer satisfaction has made us the trusted choice for home improvement.', 'windows-doors-modern'); ?></p>
                <p class="about-text"><?php echo esc_html__('We use only the finest materials from leading manufacturers like Milgard, ensuring your home receives products that will last for decades.', 'windows-doors-modern'); ?></p>
                <div class="about-features">
                    <div class="about-feature">
                        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                            <polyline points="20 6 9 17 4 12"/>
                        </svg>
                        <span><?php echo esc_html__('Licensed & Insured Professionals', 'windows-doors-modern'); ?></span>
                    </div>
                    <div class="about-feature">
                        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                            <polyline points="20 6 9 17 4 12"/>
                        </svg>
                        <span><?php echo esc_html__('Lifetime Warranty on Products', 'windows-doors-modern'); ?></span>
                    </div>
                    <div class="about-feature">
                        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                            <polyline points="20 6 9 17 4 12"/>
                        </svg>
                        <span><?php echo esc_html__('Free In-Home Consultations', 'windows-doors-modern'); ?></span>
                    </div>
                    <div class="about-feature">
                        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                            <polyline points="20 6 9 17 4 12"/>
                        </svg>
                        <span><?php echo esc_html__('Flexible Financing Available', 'windows-doors-modern'); ?></span>
                    </div>
                </div>
                <a href="#quote" class="btn btn-primary">
                    <?php echo esc_html__('Get Started Today', 'windows-doors-modern'); ?>
                    <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                        <line x1="5" y1="12" x2="19" y2="12"></line>
                        <polyline points="12 5 19 12 12 19"></polyline>
                    </svg>
                </a>
            </div>
        </div>
    </section>

    <!-- Testimonials -->
    <section class="testimonials" id="testimonials">
        <div class="container">
            <div class="section-header">
                <span class="section-badge"><?php echo esc_html__('Testimonials', 'windows-doors-modern'); ?></span>
                <h2 class="section-title"><?php echo esc_html__('What Our Customers Say', 'windows-doors-modern'); ?></h2>
                <p class="section-subtitle"><?php echo esc_html__('Don\'t just take our word for it. Here\'s what homeowners have to say about their experience.', 'windows-doors-modern'); ?></p>
            </div>
            <div class="testimonials-grid">
                <div class="testimonial-card">
                    <div class="testimonial-rating">
                        <svg width="20" height="20" viewBox="0 0 24 24" fill="currentColor"><polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"/></svg>
                        <svg width="20" height="20" viewBox="0 0 24 24" fill="currentColor"><polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"/></svg>
                        <svg width="20" height="20" viewBox="0 0 24 24" fill="currentColor"><polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"/></svg>
                        <svg width="20" height="20" viewBox="0 0 24 24" fill="currentColor"><polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"/></svg>
                        <svg width="20" height="20" viewBox="0 0 24 24" fill="currentColor"><polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"/></svg>
                    </div>
                    <p class="testimonial-text"><?php echo esc_html__('"They have been wonderful. Lots of communication and my phone is ringing off the hook! Highly recommend their services."', 'windows-doors-modern'); ?></p>
                    <div class="testimonial-author">
                        <div class="author-avatar">DB</div>
                        <div class="author-info">
                            <span class="author-name"><?php echo esc_html__('David Broadus', 'windows-doors-modern'); ?></span>
                            <span class="author-location"><?php echo esc_html__('Las Vegas, NV', 'windows-doors-modern'); ?></span>
                        </div>
                    </div>
                </div>
                <div class="testimonial-card">
                    <div class="testimonial-rating">
                        <svg width="20" height="20" viewBox="0 0 24 24" fill="currentColor"><polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"/></svg>
                        <svg width="20" height="20" viewBox="0 0 24 24" fill="currentColor"><polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"/></svg>
                        <svg width="20" height="20" viewBox="0 0 24 24" fill="currentColor"><polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"/></svg>
                        <svg width="20" height="20" viewBox="0 0 24 24" fill="currentColor"><polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"/></svg>
                        <svg width="20" height="20" viewBox="0 0 24 24" fill="currentColor"><polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"/></svg>
                    </div>
                    <p class="testimonial-text"><?php echo esc_html__('"Excellent service from start to finish. The installation team was professional and courteous. Our new windows look amazing!"', 'windows-doors-modern'); ?></p>
                    <div class="testimonial-author">
                        <div class="author-avatar">LG</div>
                        <div class="author-info">
                            <span class="author-name"><?php echo esc_html__('Lauren Gaudin', 'windows-doors-modern'); ?></span>
                            <span class="author-location"><?php echo esc_html__('Henderson, NV', 'windows-doors-modern'); ?></span>
                        </div>
                    </div>
                </div>
                <div class="testimonial-card">
                    <div class="testimonial-rating">
                        <svg width="20" height="20" viewBox="0 0 24 24" fill="currentColor"><polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"/></svg>
                        <svg width="20" height="20" viewBox="0 0 24 24" fill="currentColor"><polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"/></svg>
                        <svg width="20" height="20" viewBox="0 0 24 24" fill="currentColor"><polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"/></svg>
                        <svg width="20" height="20" viewBox="0 0 24 24" fill="currentColor"><polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"/></svg>
                        <svg width="20" height="20" viewBox="0 0 24 24" fill="currentColor"><polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"/></svg>
                    </div>
                    <p class="testimonial-text"><?php echo esc_html__('"Best investment we made for our home. The energy savings alone have been incredible. Thank you Windows & Doors!"', 'windows-doors-modern'); ?></p>
                    <div class="testimonial-author">
                        <div class="author-avatar">MR</div>
                        <div class="author-info">
                            <span class="author-name"><?php echo esc_html__('Michael Roberts', 'windows-doors-modern'); ?></span>
                            <span class="author-location"><?php echo esc_html__('Summerlin, NV', 'windows-doors-modern'); ?></span>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- CTA Section -->
    <section class="cta">
        <div class="container cta-inner">
            <div class="cta-content">
                <h2><?php echo esc_html__('Ready to Transform Your Home?', 'windows-doors-modern'); ?></h2>
                <p><?php echo esc_html__('Get your free, no-obligation quote today. Our experts are standing by to help you find the perfect solution for your home.', 'windows-doors-modern'); ?></p>
            </div>
            <div class="cta-actions">
                <a href="#quote" class="btn btn-white btn-lg"><?php echo esc_html__('Get Free Quote', 'windows-doors-modern'); ?></a>
                <a href="tel:8883832848" class="btn btn-outline-white btn-lg">
                    <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                        <path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72 12.84 12.84 0 0 0 .7 2.81 2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45 12.84 12.84 0 0 0 2.81.7A2 2 0 0 1 22 16.92z"/>
                    </svg>
                    (888) 383-2848
                </a>
            </div>
        </div>
    </section>

    <!-- Contact Section -->
    <section class="contact" id="contact">
        <div class="container contact-inner">
            <div class="contact-info">
                <span class="section-badge"><?php echo esc_html__('Contact Us', 'windows-doors-modern'); ?></span>
                <h2 class="section-title"><?php echo esc_html__('Get In Touch', 'windows-doors-modern'); ?></h2>
                <p class="contact-text"><?php echo esc_html__('Have questions? We\'re here to help. Reach out to us through any of the following methods.', 'windows-doors-modern'); ?></p>

                <div class="contact-methods">
                    <div class="contact-method">
                        <div class="method-icon">
                            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                <path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z"/>
                                <circle cx="12" cy="10" r="3"/>
                            </svg>
                        </div>
                        <div class="method-details">
                            <h4><?php echo esc_html__('Visit Us', 'windows-doors-modern'); ?></h4>
                            <p>7318 W Post Rd #210<br>Las Vegas, NV 89113</p>
                        </div>
                    </div>
                    <div class="contact-method">
                        <div class="method-icon">
                            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                <path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72 12.84 12.84 0 0 0 .7 2.81 2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45 12.84 12.84 0 0 0 2.81.7A2 2 0 0 1 22 16.92z"/>
                            </svg>
                        </div>
                        <div class="method-details">
                            <h4><?php echo esc_html__('Call Us', 'windows-doors-modern'); ?></h4>
                            <p>(888) 383-2848<br><?php echo esc_html__('Mon-Sat: 8am - 6pm', 'windows-doors-modern'); ?></p>
                        </div>
                    </div>
                    <div class="contact-method">
                        <div class="method-icon">
                            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                <path d="M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z"/>
                                <polyline points="22,6 12,13 2,6"/>
                            </svg>
                        </div>
                        <div class="method-details">
                            <h4><?php echo esc_html__('Email Us', 'windows-doors-modern'); ?></h4>
                            <p>info@windowsanddoors.com<br><?php echo esc_html__('We reply within 24 hours', 'windows-doors-modern'); ?></p>
                        </div>
                    </div>
                </div>
            </div>
            <div class="contact-map">
                <div class="map-placeholder">
                    <svg width="48" height="48" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5">
                        <path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z"/>
                        <circle cx="12" cy="10" r="3"/>
                    </svg>
                    <span><?php echo esc_html__('Las Vegas, NV', 'windows-doors-modern'); ?></span>
                    <a href="https://maps.google.com" target="_blank" rel="noopener noreferrer" class="btn btn-sm btn-outline"><?php echo esc_html__('View on Google Maps', 'windows-doors-modern'); ?></a>
                </div>
            </div>
        </div>
    </section>

<?php get_footer(); ?>
