<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
    <meta charset="<?php bloginfo('charset'); ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <?php wp_head(); ?>
</head>
<body <?php body_class(); ?>>
<?php wp_body_open(); ?>

    <!-- Announcement Bar -->
    <div class="announcement-bar">
        <div class="container">
            <p><span class="highlight"><?php echo esc_html__('Limited Time Offer:', 'windows-doors-modern'); ?></span> <?php echo esc_html__('Get $100 Gift Card with purchases over $2,000', 'windows-doors-modern'); ?> <a href="#quote"><?php echo esc_html__('Get Quote', 'windows-doors-modern'); ?></a></p>
        </div>
    </div>

    <!-- Header -->
    <header class="header">
        <div class="container header-inner">
            <a href="<?php echo esc_url(home_url('/')); ?>" class="logo">
                <div class="logo-icon">
                    <svg viewBox="0 0 40 40" fill="none" xmlns="http://www.w3.org/2000/svg">
                        <rect x="4" y="8" width="32" height="24" rx="2" stroke="currentColor" stroke-width="2"/>
                        <line x1="20" y1="8" x2="20" y2="32" stroke="currentColor" stroke-width="2"/>
                        <line x1="4" y1="20" x2="36" y2="20" stroke="currentColor" stroke-width="2"/>
                    </svg>
                </div>
                <div class="logo-text">
                    <span class="logo-name"><?php echo esc_html(get_bloginfo('name')); ?></span>
                    <span class="logo-tagline"><?php echo esc_html(get_bloginfo('description')); ?></span>
                </div>
            </a>

            <nav class="nav">
                <?php
                wp_nav_menu([
                    'theme_location' => 'primary',
                    'container'      => false,
                    'items_wrap'     => '%3$s',
                    'depth'          => 1,
                    'link_before'    => '',
                    'link_after'     => '',
                    'fallback_cb'    => function() {
                        ?>
                        <a href="<?php echo esc_url(home_url('/')); ?>" class="nav-link active"><?php echo esc_html__('Home', 'windows-doors-modern'); ?></a>
                        <a href="#services" class="nav-link"><?php echo esc_html__('Services', 'windows-doors-modern'); ?></a>
                        <a href="#about" class="nav-link"><?php echo esc_html__('About', 'windows-doors-modern'); ?></a>
                        <a href="#testimonials" class="nav-link"><?php echo esc_html__('Testimonials', 'windows-doors-modern'); ?></a>
                        <a href="#contact" class="nav-link"><?php echo esc_html__('Contact', 'windows-doors-modern'); ?></a>
                        <?php
                    },
                ]);
                ?>
            </nav>

            <div class="header-actions">
                <a href="tel:8883832848" class="phone-link">
                    <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                        <path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72 12.84 12.84 0 0 0 .7 2.81 2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45 12.84 12.84 0 0 0 2.81.7A2 2 0 0 1 22 16.92z"/>
                    </svg>
                    (888) 383-2848
                </a>
                <a href="#quote" class="btn btn-primary"><?php echo esc_html__('Get Free Quote', 'windows-doors-modern'); ?></a>
            </div>

            <button class="mobile-menu-btn" aria-label="<?php echo esc_attr__('Menu', 'windows-doors-modern'); ?>">
                <span></span>
                <span></span>
                <span></span>
            </button>
        </div>
    </header>
